import os

l1size=["2kB","4kB", "8kB", "16kB", "32kB", "64kB"]
cachelinesize=["16", "32", "64", "128", "256"]

os.chdir("/home/narek/gem5")

for x in l1size:
    for y in cachelinesize:
        os.system("./build/X86/gem5.fast configs/example/se.py --ruby --l1d_size=" + x + " --cacheline_size=" + y + " -c matmul.x86 --options='50 50 50'")
        os.system("cp /home/narek/gem5/m5out/stats.txt /home/narek/Desktop/Part_A_Results/" + x + "_" + y + ".txt")
        print("done with " + x + "_" + y)

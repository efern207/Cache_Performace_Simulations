import os

l1size=["8kB"]
l1assoc=["1", "2", "4", "8", "16"]

os.chdir("/home/narek/gem5")

for x in l1size:
    for y in l1assoc:
        os.system("./build/X86/gem5.fast configs/example/se.py --ruby --l1d_size=" + x + " --l1d_assoc=" + y + " -c matmul.x86 --options='50 50 50'")
        os.system("cp /home/narek/gem5/m5out/stats.txt /home/narek/Desktop/Part_B_Results/" + x + "_" + y + ".txt")
        print("done with " + x + "_" + y)
